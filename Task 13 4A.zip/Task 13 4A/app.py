from flask import Flask, render_template, request, jsonify
from transformers import pipeline
import json
import re

app = Flask(__name__)

# Load restaurant data
with open('restaurants.json', 'r') as f:
    restaurants_data = json.load(f)

# Extract cuisines and zones
all_cuisines =sorted({cuisine for zone in restaurants_data for rest in restaurants_data[zone] for cuisine in rest['cuisines']})
all_zones =sorted(restaurants_data.keys())

# Load text2text GenAI model
try:
    qa_pipeline = pipeline("text2text-generation", model="google/flan-t5-small")
    print("✅ NLP model loaded successfully!")
except Exception as e:
    print(f"⚠️ Warning:Could not load NLP model: {e}")
    print("⚠️ Falling back to keyword matching")
    qa_pipeline = None

def extract_entities(user_input):
    """Use Flan-T5 to extract cuisine and zone from user input."""
    try:
        if qa_pipeline:
            cuisine_prompt = f"What type of cuisine is mentioned in: '{user_input}'? If none, respond with 'None'."
            zone_prompt = f"What area or zone in Lahore is mentioned in: '{user_input}'? If none, respond with 'None'."

            cuisine_response = qa_pipeline(cuisine_prompt, max_length=20)[0]['generated_text']
            zone_response = qa_pipeline(zone_prompt, max_length=20)[0]['generated_text']

            cuisine = cuisine_response.strip().title()
            zone = zone_response.strip().title()

            # Normalize
            cuisine = cuisine if cuisine.lower() != "none" else ""
            zone = zone if zone.lower() != "none" else ""
            
            print(f"NLP extracted: Cuisine='{cuisine}', Zone='{zone}' from '{user_input}'")
            return cuisine, zone
        else:
            # Fallback to simple keyword matching
            return keyword_matching(user_input)
    except Exception as e:
        print(f"Error extracting entities: {e}")
        return keyword_matching(user_input)

def keyword_matching(user_input):
    """Simple keyword matching for cuisines and zones."""
    user_input = user_input.lower()
    
    # Check for cuisines
    matched_cuisine = ""
    for cuisine in all_cuisines:
        if cuisine.lower() in user_input:
            matched_cuisine = cuisine
            break
    
    # Check for zones
    matched_zone = ""
    for zone in all_zones:
        if zone.lower() in user_input:
            matched_zone = zone
            break
    
    print(f"Keyword matching: Cuisine='{matched_cuisine}', Zone='{matched_zone}' from '{user_input}'")
    return matched_cuisine, matched_zone

@app.route('/')
def home():
    return render_template('index.html', zones=all_zones, cuisines=all_cuisines)

@app.route('/get_response', methods=['POST'])
def get_response():
    # Get the cuisine and zone from the request
    user_cuisine = request.json.get('cuisine', '')
    user_zone = request.json.get('zone', '')
    
    # Check if this is a natural language query (when zone is empty but cuisine has content)
    if user_cuisine and not user_zone:
        # This is likely a natural language query
        extracted_cuisine, extracted_zone = extract_entities(user_cuisine)
        
        # If we extracted entities, use them
        if extracted_cuisine or extracted_zone:
            user_cuisine = extracted_cuisine
            user_zone = extracted_zone
    
    # Smart fuzzy matching
    selected_cuisines = [c for c in all_cuisines if user_cuisine.lower() in c.lower()]
    selected_zones = [z for z in all_zones if user_zone.lower() in z.lower()]

    matching_restaurants = []

    if selected_cuisines and selected_zones:
        for z in selected_zones:
            for rest in restaurants_data.get(z, []):
                if any(c in rest["cuisines"] for c in selected_cuisines):
                    matching_restaurants.append({
                        "name": rest["name"],
                        "address": rest["address"],
                        "zone": z,
                        "menu": rest["menu"]
                    })

        if matching_restaurants:
            response = f"🍽️ Found {len(matching_restaurants)} restaurant(s) offering {', '.join(selected_cuisines)} in {', '.join(selected_zones)}:\n\n"
            for i, r in enumerate(matching_restaurants, 1):
                response += f"{i}. **{r['name']}** - {r['address']} ({r['zone']})\n   📜 Menu: {r['menu']}\n\n"
            return jsonify({'message': response})

        else:
            return jsonify({'message': f"😕 No {', '.join(selected_cuisines)} restaurants found in {', '.join(selected_zones)}."})

    elif selected_cuisines:
        return jsonify({'message': f"👍 You selected {user_cuisine}. Please specify the zone (e.g., Gulberg, DHA)."})

    elif selected_zones:
        return jsonify({'message': f"📍 You selected {user_zone}. What type of cuisine are you interested in?"})

    else:
        # Check if this was a natural language query that we couldn't extract from
        if user_cuisine and not user_zone and not selected_cuisines and not selected_zones:
            return jsonify({'message': f"I couldn't understand what cuisine or zone you're looking for in '{user_cuisine}'. Please try being more specific or use the dropdown menus below."})
        else:
            return jsonify({'message': "Hi! 🤖 You can ask me for restaurant recommendations by cuisine and area. Try: *'Suggest Chinese food in Gulberg'*."})

if __name__ == '__main__':
    print("🔥 Starting Lahore Restaurant Bot (with GenAI)...")
    app.run(debug=True)



